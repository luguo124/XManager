<?php

namespace App\Provider\Command;

use App\Http\Models\Package;
use App\Http\Models\Server;
use App\Helpers\DatatablesHelper;
use App\Components\Subscribe as URI;
use App\Components\Configure;

class Upgrade
{
    public function package_upgrade()
    {
		$packages = Package::all();
		foreach ($packages as $package) {
			$content = json_decode($package->content, true);
			$package->buy_count 		= $package->allow_buy_count;
			$package->bandwidth 		= $content['bandwidth'];
			$package->level 			= (int)$content['level'];
			$package->speedlimit 		= (int)$content['speedlimit'];
			$package->connector 		= (int)$content['connector'];
			$package->group 			= (int)$content['groups'];
			$package->reset 			= (int)$content['enable_reset'];
			$package->reset_every_days 	= (int)$content['reset_every_days'];
			$package->status 			= 0;
			$custom = array();	
			$custom['status'] 			= 0;
			$custom['expire'] 			= $package->type == 1 ? "0" : $package->expire_days;
			$custom['price'] 			= $package->price;
			$package->custom 			= json_encode($custom);
			$package->save();
		}	
    }
	
    public function servers_upgrade()
    {
		$servers = Server::all();
		foreach ($servers as $server) {
			$serverr = Server::find($server->id);
			$serve = explode(';', $serverr->server);
			$opt    = [];
			
			if($server->sort == 2)
			{
				$serverr->sort  = 4;
			}elseif($server->sort == 3){
				$serverr->sort  = 5;
			}
			
			if($server->sort == 2 || $server->sort == 3){
				$opt = URI::parse_args($serve[5]);
				$serverr->server		 = $serve[0];
				$serverr->security       = $serve[4];
				$serverr->protocol       = $serve[3];
				$serverr->xpath          = (isset($opt['path']) ? $opt['path'] :(isset($opt['servicename']) ? $opt['servicename'] : ''));
				$serverr->flow           = (isset($opt['flow']) ? $opt['flow'] :'none');
				$serverr->port     		 = (int)$serve[1];
			}
			
			if($server->sort == 0){
				$opt = URI::parse_args($serve[1]);
				$serverr->sort  		= 1;
				$serverr->server		= $serve[0];
				$serverr->port     		= (isset($opt['port']) ? (int)$opt['port'] :'');
				$serverr->security      = "tls";
			}
			
			if($server->sort == 1){
				$opt = URI::parse_args($serve[1]);
				$serverr->sort  		= 3;
				$serverr->server		= $serve[0];
				$serverr->protocol      = (isset($opt['grpc']) ? "grpc" : 'tcp');
				$serverr->port     		= (isset($opt['port']) ? (int)$opt['port'] :'');
				$serverr->xpath         = (isset($opt['servicename']) ? $opt['servicename'] : '');
				$serverr->flow          = (isset($opt['flow']) ? $opt['flow'] :'none');
				$serverr->security      = (isset($opt['xtls']) ? 'xtls' : 'tls');
			}
			
			if($server->sort == 4){
				$opt = URI::parse_args($server[1]);
				$serverr->sort  		= 2;
				$serverr->port     		= (int)$serve[1];
				$serverr->protocol      = $serve[3];
				$serverr->server		= $serve[0];
				$serverr->security      = $serve[4];
				$serverr->xpath         = (isset($opt['path']) ? $opt['path'] :'');
			}	
			
			$serverr->outside_port     	= (isset($opt['outside_port']) ? (int)$opt['outside_port'] : "");
			$serverr->xhost            	= (isset($opt['host']) ? $opt['host'] : '');
			$serverr->allowinsecure    	= 0;
			$serverr->headertype		= (isset($opt['headertype']) ? $opt['headertype'] : 'none');
			$serverr->save();
		}		
	}	

	public function xmanager_upgrade()
    {
		(new Upgrade())->package_upgrade();
		(new Upgrade())->servers_upgrade();
		echo "successful";
	}
	
}
