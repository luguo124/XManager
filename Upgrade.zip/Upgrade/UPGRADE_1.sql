DELETE FROM `MyxPanel`.`config` WHERE `config`.`name` = 'GoogleAuth';
DELETE FROM `MyxPanel`.`config` WHERE `config`.`name` = 'GoogleClientID';
DELETE FROM `MyxPanel`.`config` WHERE `config`.`name` = 'GoogleEmail';
DELETE FROM `MyxPanel`.`config` WHERE `config`.`name` = 'GoogleToken';
DELETE FROM `MyxPanel`.`config` WHERE `config`.`name` = 'GoogleSecret';
DELETE FROM `MyxPanel`.`config` WHERE `config`.`name` = 'WebapiSafe';