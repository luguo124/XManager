DELETE FROM `manager`.`config` WHERE `config`.`name` = 'GoogleAuth';
DELETE FROM `manager`.`config` WHERE `config`.`name` = 'GoogleClientID';
DELETE FROM `manager`.`config` WHERE `config`.`name` = 'GoogleEmail';
DELETE FROM `manager`.`config` WHERE `config`.`name` = 'GoogleToken';
DELETE FROM `manager`.`config` WHERE `config`.`name` = 'GoogleSecret';
DELETE FROM `manager`.`config` WHERE `config`.`name` = 'WebapiSafe';