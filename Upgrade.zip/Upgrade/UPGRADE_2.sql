DROP TABLE `bought`;
DROP TABLE `email_queue`;
DROP TABLE `pay_qrcode`;

INSERT INTO `config` (`name`, `value`) VALUES
('alipay', '1'),
('app_color', '#168ea1'),
('cloudflare_domain', ''),
('cloudflare_email', ''),
('cloudflare_key', ''),
('comm_pay_once', '0'),
('cp_currency', 'BTC'),
('cp_currency_code', 'CNY'),
('cp_private_key', ''),
('cp_public_key', ''),
('default_currency', 'CNY'),
('default_currency_symbol', '¥'),
('easypay_currency_code', 'CNY'),
('email_loginverify', '0'),
('enable_cloudflare', '0'),
('enable_coinpayments', '0'),
('enable_easypay', '0'),
('enable_easypay_alipay', '0'),
('enable_easypay_wechat', '0'),
('enable_f2fpay', '0'),
('enable_google_analytics', '0'),
('enable_mgate', '0'),
('enable_rebate', '0'),
('enable_stripe', '0'),
('enable_stripe_alipay', '0'),
('enable_stripe_wechat', '0'),
('enable_theadpay', '0'),
('enable_vpay', '0'),
('enable_vpay_alipay', '0'),
('enable_vpay_wechat', '0'),
('f2fpay_currency_code', 'CNY'),
('f2fpay_private_key', ''),
('f2fpay_public_key', ''),
('ga_auth_loginverify', '0'),
('googleauth', NULL),
('googleclientid', ''),
('googleemail', ''),
('googlesecret', ''),
('googletoken', ''),
('google_analytics_id', ''),
('google_tracking_id', ''),
('mgate_currency_code', 'CNY'),
('mobile_loginverify', '0'),
('rememberme', '7'),
('stripe_currency_code', 'CNY'),
('theadpay_currency_code', 'CNY'),
('trafficexpnotify', '0'),
('trafficexpnotifydays', '1,3,5,7'),
('trafficusednotify', '0'),
('trafficusednotifylimit', '100,200,500'),
('user_language_select', '1'),
('vpay_currency_code', 'CNY'),
('vpay_order_exp', '5'),
('webapisafe', NULL);

CREATE TABLE IF NOT EXISTS `currency` (
  `id` int(11) NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `code` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `symbol` varchar(5) CHARACTER SET utf8 DEFAULT NULL,
  `rate` decimal(12,2) NOT NULL DEFAULT '0.00',
  `status` int(2) NOT NULL DEFAULT '0',
  `updatetime` bigint(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;


INSERT INTO `currency` (`id`, `name`, `code`, `symbol`, `rate`, `status`, `updatetime`) VALUES
(1, 'United States Dollars', 'USD', '$', '0.16', 1, 1636502401),
(2, 'British Pounds', 'GBP', '£', '0.12', 1, 1636502401),
(3, 'Euro', 'EUR', '€', '0.14', 1, 1636502401),
(4, 'Japanese Yen', 'JPY', '¥', '17.68', 1, 1636502401),
(5, 'Chinese Yuan Renminbi', 'CNY', '¥', '1.00', 1, 1636502401),
(6, 'Canadian Dollars', 'CAD', '$', '0.20', 1, 1636502401),
(7, 'Hongkng Dollars', 'HKD', '$', '1.22', 1, 1636502401),
(8, 'India Rupees', 'INR', '₹', '11.60', 1, 1636502401),
(9, 'Russian Rubles', 'RUB', '₽', '11.11', 1, 1636502401),
(10, 'New Taiwan dollars', 'TWD', 'NT$', '4.35', 1, 1636502401);

CREATE TABLE IF NOT EXISTS `onlineip` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `email` varchar(250) NOT NULL,
  `ip` longtext NOT NULL,
  `datetime` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


ALTER TABLE `orders` ADD `exrate` decimal(12,2) NOT NULL;

ALTER TABLE `package` ADD  `bandwidth` text NOT NULL;
ALTER TABLE `package` ADD  `buy_count` varchar(11) NOT NULL DEFAULT '0';
ALTER TABLE `package` ADD  `custom` varchar(500) NOT NULL DEFAULT '{"expire":"30","price":0,"status":0}';
ALTER TABLE `package` ADD  `monthly` varchar(500) NOT NULL DEFAULT '{"expire":"30","price":0,"status":0}';
ALTER TABLE `package` ADD  `quaterly` varchar(500) NOT NULL DEFAULT '{"expire":"90","price":0,"status":0}';
ALTER TABLE `package` ADD  `semiannually` varchar(500) NOT NULL DEFAULT '{"expire":"180","price":0,"status":0}';
ALTER TABLE `package` ADD  `annually` varchar(500) NOT NULL DEFAULT '{"expire":"360","price":0,"status":0}';
ALTER TABLE `package` ADD  `reset` int(5) NOT NULL DEFAULT '0';
ALTER TABLE `package` ADD  `reset_every_days` int(10) NOT NULL DEFAULT '30';
ALTER TABLE `package` ADD  `connector` int(5) NOT NULL DEFAULT '2';
ALTER TABLE `package` ADD  `speedlimit` int(10) NOT NULL DEFAULT '0';
ALTER TABLE `package` ADD  `group` int(5) NOT NULL DEFAULT '1';
ALTER TABLE `package` ADD  `level` int(5) NOT NULL DEFAULT '0';


ALTER TABLE `servers` ADD `headertype` text NOT NULL;
ALTER TABLE `servers` ADD `port` int(10) NOT NULL DEFAULT '443';
ALTER TABLE `servers` ADD `outside_port` int(10) NOT NULL;
ALTER TABLE `servers` ADD `protocol` text NOT NULL;
ALTER TABLE `servers` ADD `flow` text NOT NULL;
ALTER TABLE `servers` ADD `security` varchar(5) NOT NULL DEFAULT 'tls';
ALTER TABLE `servers` ADD `xhost` longtext NOT NULL;
ALTER TABLE `servers` ADD `xpath` longtext NOT NULL;
ALTER TABLE `servers` ADD `rserver` VARCHAR(300) NULL DEFAULT NULL;
ALTER TABLE `servers` CHANGE COLUMN `traffic_rate` `rate` float NOT NULL DEFAULT '1';
ALTER TABLE `servers` CHANGE COLUMN `node_class` `level` int(11) NOT NULL DEFAULT '0';
ALTER TABLE `servers` CHANGE COLUMN `node_speedlimit` `speedlimit` int(20) NOT NULL DEFAULT '0';
ALTER TABLE `servers` CHANGE COLUMN `node_connector` `connector` int(11) NOT NULL DEFAULT '0';
ALTER TABLE `servers` CHANGE COLUMN `node_bandwidth` `bandwidth` bigint(20) NOT NULL DEFAULT '0';
ALTER TABLE `servers` CHANGE COLUMN `node_bandwidth_limit` `bandwidth_limit` bigint(20) NOT NULL DEFAULT '0';
ALTER TABLE `servers` CHANGE COLUMN `node_heartbeat` `heartbeat` bigint(20) NOT NULL DEFAULT '0';
ALTER TABLE `servers` CHANGE COLUMN `node_group` `group` int(11) NOT NULL DEFAULT '0';
ALTER TABLE `servers` ADD `allowinsecure` tinyint(2) NOT NULL DEFAULT '0';

ALTER TABLE `user` CHANGE COLUMN `node_group` `group` int(11) NOT NULL DEFAULT '0';
ALTER TABLE `user` CHANGE COLUMN `class` `level` int(11) NOT NULL DEFAULT '0';
ALTER TABLE `user` CHANGE COLUMN `node_speedlimit` `speedlimit` int(20) NOT NULL DEFAULT '0';
ALTER TABLE `user` CHANGE COLUMN `node_connector` `connector` int(11) NOT NULL DEFAULT '0';
ALTER TABLE `user` CHANGE COLUMN `is_admin` `role` int(2) NOT NULL DEFAULT '0';
ALTER TABLE `user` ADD `affclicks` int(20) NOT NULL DEFAULT '0';
ALTER TABLE `user` ADD `ga_token` varchar(200) NOT NULL;
ALTER TABLE `user` ADD `ga_enable` int(5) NOT NULL DEFAULT '0';
ALTER TABLE `user` ADD `reset_count` int(3) NOT NULL DEFAULT '0';
ALTER TABLE `user` ADD `notify_expire` int(2) NOT NULL DEFAULT '1';
ALTER TABLE `user` ADD `notify_usedup` int(2) NOT NULL DEFAULT '1';
ALTER TABLE `user` ADD `traffic_notified_limit` tinyint(1) NOT NULL DEFAULT '0';
ALTER TABLE `user` ADD `expire_notified_days` tinyint(1) NOT NULL DEFAULT '0';

ALTER TABLE `currency` ADD PRIMARY KEY (`id`);
ALTER TABLE `currency` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1;  

	